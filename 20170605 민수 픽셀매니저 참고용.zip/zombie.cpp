#include "stdafx.h"
#include "zombie.h"


zombie::zombie()
{
}


zombie::~zombie()
{

}

HRESULT zombie::init(float x, float y)
{
	_enemyImage = IMAGEMANAGER->findImage(L"zombie");
	_enemyHitImage = IMAGEMANAGER->findImage(L"zombie_hit");
	_enemyDeadImage = IMAGEMANAGER->findImage(L"zombie_die");
	_count = _index = 0;
	_isLeft = RND->getFromIntTo(0, 1);

	_hitRect = RectMake(0, 0, 0, 0);
	_atkRect = RectMakeCenter(_x, _y - _enemyImage->getFrameHeight() / 2, _enemyImage->getFrameWidth() - 20, _enemyImage->getFrameHeight());

	_x = x;
	_y = y;

	_hp = 25;

	_atk = 10;

	_hitTimer = 0;
	_isHit = false;
	_alpha = 255;

	_aliveTimer = 20;
	_isSelfDestroy = false;
	_isDestroyByHit = false;

	return S_OK;
}

void zombie::release(void)
{

}

void zombie::update(void)
{
	if (_hp <= 0)
	{
		_hitRect = RectMake(0, 0, 0, 0);
		_atkRect = RectMake(0, 0, 0, 0);
	}
	else
	{
		if (_index >= 7)
		{
			_hitRect = RectMakeCenter(_x, _y - _enemyImage->getFrameHeight() / 2, _enemyImage->getFrameWidth() - 40, _enemyImage->getFrameHeight());

			if (_isHit)
			{
				_hitTimer += TIMEMANAGER->getElapsedTime();

				if (_hitTimer >= 0.2f)
				{
					_hitTimer = 0;
					_isHit = false;
				}
			}
		}

		if (_index > 7)
		{
			if (_isLeft)
			{
				_x -= 0.7f;
			}
			else
			{
				_x += 0.7f;
			}
		}

		_aliveTimer -= TIMEMANAGER->getElapsedTime();

		if (_x < 1918.0f + _enemyImage->getFrameWidth() / 2 || _x > 6238.0f - _enemyImage->getFrameWidth() / 2)
		{
			_aliveTimer = 0;
		}

		if (_aliveTimer <= 0)
		{
			_hitRect = RectMake(0, 0, 0, 0);
			_atkRect = RectMake(0, 0, 0, 0);
		}
	}
}

void zombie::render(void)
{
	if (KEYMANAGER->isToggleKey(VK_F1))
	{
		Rectangle(getMemDC(), _hitRect.left - _ptCamera.x, _hitRect.top - _ptCamera.y, _hitRect.right - _ptCamera.x, _hitRect.bottom - _ptCamera.y);
		Rectangle(getMemDC(), _atkRect.left - _ptCamera.x, _atkRect.top - _ptCamera.y, _atkRect.right - _ptCamera.x, _atkRect.bottom - _ptCamera.y);
	}

	_count += TIMEMANAGER->getElapsedTime();

	if (_hp <= 0)
	{
		_index = 0;
		_alpha -= 10;

		if (_alpha <= 0)
		{
			_alpha = 0;
			_isDestroyByHit = true;
		}

		if (_isLeft)
		{
			_enemyDeadImage->frameRender(getMemDC(),
				_x - _enemyDeadImage->getFrameWidth() / 2 + 20 - _ptCamera.x,
				_y - _enemyDeadImage->getFrameHeight() - _ptCamera.y,
				_index, _isLeft, _alpha);
		}
		else
		{
			_enemyDeadImage->frameRender(getMemDC(),
				_x - _enemyDeadImage->getFrameWidth() / 2 - 20 - _ptCamera.x,
				_y - _enemyDeadImage->getFrameHeight() - _ptCamera.y,
				_index, _isLeft, _alpha);
		}
	}
	else
	{
		if (_aliveTimer <= 0.0f)
		{
			if (_count >= 0.1f)
			{
				if (_index > 7) _index = 7;
				--_index;
				_count = 0;
			}

			if (_index <= 0)
			{
				_isSelfDestroy = true;
			}

			_enemyImage->frameRender(getMemDC(),
				_x - _enemyImage->getFrameWidth() / 2 - _ptCamera.x,
				_y - _enemyImage->getFrameHeight() - _ptCamera.y,
				_index, _isLeft);
		}
		else
		{
			if (_isHit)
			{
				if (_count >= 0.6f)
				{
					++_index;
					if (_index > _enemyHitImage->getMaxFrameX()) _index = 7;
					_count = 0;
				}

				_enemyHitImage->frameRender(getMemDC(),
					_x - _enemyHitImage->getFrameWidth() / 2 - _ptCamera.x,
					_y - _enemyHitImage->getFrameHeight() - _ptCamera.y,
					_index, _isLeft);
			}
			else
			{
				if (_index < 7)
				{
					if (_count >= 0.1f)
					{
						++_index;
						if (_index > _enemyImage->getMaxFrameX()) _index = 7;
						_count = 0;
					}
				}
				else
				{
					if (_count >= 0.6f)
					{
						++_index;
						if (_index > _enemyImage->getMaxFrameX()) _index = 7;
						_count = 0;
					}
				}

				_enemyImage->frameRender(getMemDC(),
					_x - _enemyImage->getFrameWidth() / 2 - _ptCamera.x,
					_y - _enemyImage->getFrameHeight() - _ptCamera.y,
					_index, _isLeft);
			}
		}
	}
}
