#include "stdafx.h"
#include "progressBar.h"


progressBar::progressBar()
{
}


progressBar::~progressBar()
{

}

HRESULT progressBar::init(const WCHAR* imageName, int x, int y)
{
	_x = x;
	_y = y;

	_progressBar = IMAGEMANAGER->findImage(imageName);

	_width = _progressBar->getWidth();

	return S_OK;
}

void progressBar::release()
{

}

void progressBar::update() 
{

}

void progressBar::render() 
{
	_progressBar->render(getMemDC(), _x, _y,
		0, 0, _width, _progressBar->getHeight());
}


void progressBar::setGauge(float currentGauge, float maxGauge)
{
	//���� ���ϴ� �����̴� �Ӹ��� �־�y
	_width = (currentGauge / maxGauge) * _progressBar->getWidth();
}
