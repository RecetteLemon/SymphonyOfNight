#include "stdafx.h"
#include "enemy.h"


enemy::enemy()
{
}


enemy::~enemy()
{

}

HRESULT enemy::init(float x, float y)
{

	return S_OK;
}

void enemy::release(void)
{

}

void enemy::update(void)
{

}

void enemy::render(void)
{

}

void enemy::collision()
{
	RECT tempRect;

	if (!_isHit)
	{
		if (IntersectRect(&tempRect, &_player->getAtkRect(), &_hitRect))
		{
			_hp -= _player->getAtk();
			_isHit = true;
			SOUNDMANAGER->play("sword_hit", _volume);
//			cout << _hp << endl;
		}
	}
}