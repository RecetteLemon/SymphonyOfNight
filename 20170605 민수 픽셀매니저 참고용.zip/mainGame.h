#pragma once
#include "gameNode.h"
#include "player.h"
#include "progressBar.h"
#include "zombie.h"

enum ENEMY_TYPE
{
	ZOMBIE,
};

class mainGame : public gameNode
{
private:

	vector<enemy*> _vEnemy;
	vector<enemy*>::iterator _viEnemy;

	float _zombieGen;

private:
	player* _player;

	POINT _ptMaxCamera;
	POINT _ptMinCamera;

	image* _HUD;
	progressBar* _hpBar;
	progressBar* _spBar;

public:
	virtual HRESULT init(void);
	virtual void release(void);
	virtual void update(void);
	virtual void render(void);

	void setPlayerCamera();

	void collision();
	
	void spawnEnemy(ENEMY_TYPE type, float x, float y);

	mainGame();
	~mainGame();
};

