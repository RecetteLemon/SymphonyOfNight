#include "stdafx.h"
#include "player.h"


player::player()
{
}


player::~player()
{
}

HRESULT player::init(void)
{
	_imageName = L"p_idle";

	_x = WINSIZEX / 2;
	_y = 2456.0f;

	_hitRect = RectMakeCenter(_x, _y - IMAGEMANAGER->findImage(L"p_idle")->getFrameHeight() / 2 - 50,
		IMAGEMANAGER->findImage(L"p_idle")->getFrameWidth() - 20,
		IMAGEMANAGER->findImage(L"p_idle")->getFrameHeight() - 60);

	_atkRect = RectMake(0, 0, 0, 0);

	_count = _index = 0;
	_isLeft = false;
	_isAttack = false;
	_isGetDown = false;
	_gravity = 0;
	_jumpPower = 0;
	_jumpCount = 0;

	_maxHp = _hp = 100;
	_maxSp = _sp = 100;
	_atk = 10;

	_isHit = false;
	_hitTimer = 0;

	_alpha = 255;

	// ����׿�
	debug_x = debug_y = 0;

	return S_OK;
}

void player::release(void)
{

}

void player::update(void)
{
	move();

	if (_isHit)
	{
		_alpha = 150;
		if (_hitTimer >= 1.0f)
		{
			_hitTimer = 0;
		}

		_isAttack = false;
		_isGetDown = false;
		_imageName = L"p_hit";
		_hitRect = RectMake(0, 0, 0, 0);
		_hitTimer += TIMEMANAGER->getElapsedTime();

		if (_hitTimer >= 0.5f)
		{
			_imageName = L"p_idle";
			_isHit = false;
		}
	}
	else
	{
		if (_hitTimer < 1.0f)
		{
			_hitTimer += TIMEMANAGER->getElapsedTime();
		}
		else
		{
			_alpha = 255;

			_hitRect = RectMakeCenter(_x, _y - IMAGEMANAGER->findImage(L"p_idle")->getFrameHeight() / 2 - 10,
				IMAGEMANAGER->findImage(L"p_idle")->getFrameWidth() - 20,
				IMAGEMANAGER->findImage(L"p_idle")->getFrameHeight() - 40);
		}
	}

	if (_sp > _maxSp)
	{
		_sp = _maxSp;
	}
}

void player::render(void)
{
	if (KEYMANAGER->isToggleKey(VK_F1))
	{
		Rectangle(getMemDC(), _hitRect.left - _ptCamera.x, _hitRect.top - _ptCamera.y, _hitRect.right - _ptCamera.x, _hitRect.bottom - _ptCamera.y);
		Rectangle(getMemDC(), _atkRect.left - _ptCamera.x, _atkRect.top - _ptCamera.y, _atkRect.right - _ptCamera.x, _atkRect.bottom - _ptCamera.y);
	}

	// ������ ����
	_count += TIMEMANAGER->getElapsedTime();

	if (_imageName == L"p_attack" || _imageName == L"p_airAttack" || _imageName == L"p_sitAttack")
	{
		if (_count > 0.04f)
		{
			++_index;
			_count = 0;
			++_sp;
		}
	}
	else
	{
		if (_count > 0.06f)
		{
			++_index;
			_count = 0;
			++_sp;
		}
	}

	// ��Ȳ�� ���� �̹��� ����
	if (_imageName == L"p_jump")
	{
		if (_jumpPower > 0 && _index > 7)
		{
			_index = 7;
		}
		if (_jumpPower <= 0 && _gravity > 0 && (_index > 10 || _index < 8))
		{
			_index = 8;
		}

		if (_index > IMAGEMANAGER->findImage(_imageName)->getMaxFrameX())
		{
			_index = 0;
			_imageName = L"p_idle";
		}
		
		if (_isLeft)
		{
			IMAGEMANAGER->findImage(_imageName)->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(_imageName)->getFrameWidth() / 2) - _ptCamera.x + 6,
				(_y - IMAGEMANAGER->findImage(_imageName)->getFrameHeight()) - _ptCamera.y,
				_index, _isLeft, _alpha);
		}
		else
		{
			IMAGEMANAGER->findImage(_imageName)->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(_imageName)->getFrameWidth() / 2) - _ptCamera.x - 6,
				(_y - IMAGEMANAGER->findImage(_imageName)->getFrameHeight()) - _ptCamera.y,
				_index, _isLeft, _alpha);
		}
	}
	else if (_imageName == L"p_sit")
	{
		if (_index > IMAGEMANAGER->findImage(_imageName)->getMaxFrameX()) _index = IMAGEMANAGER->findImage(_imageName)->getMaxFrameX();
	}
	else if (_imageName == L"p_attack")
	{
		if (_index > IMAGEMANAGER->findImage(_imageName)->getMaxFrameX())
		{
			_isAttack = false;
			_index = 0;
			_imageName = L"p_idle";
		}
	}
	else if (_imageName == L"p_airAttack")
	{
		if (_index > IMAGEMANAGER->findImage(_imageName)->getMaxFrameX()) _index = IMAGEMANAGER->findImage(_imageName)->getMaxFrameX();

		if ((PIXELMANAGER->getPixelCollisionY(IMAGEMANAGER->findImage(_imageName), _x, _y, IMAGEMANAGER->findImage(L"���浹")) != NULL && _jumpPower <= 0) ||
			PIXELMANAGER->pixelPlateCollision(IMAGEMANAGER->findImage(_imageName), _x, _y, IMAGEMANAGER->findImage(L"���浹")) != NULL)
		{
			_isAttack = false;
		}
	}
	else if (_imageName == L"p_sitAttack")
	{
		if (_index > IMAGEMANAGER->findImage(_imageName)->getMaxFrameX())
		{
			_isAttack = false;
			_imageName = L"p_sit";
			_index = IMAGEMANAGER->findImage(_imageName)->getMaxFrameX();
		}
	}
	else if (_imageName == L"p_backStep")
	{
		if (_backStepTimer >= 0.15f)
		{
			if (_index > IMAGEMANAGER->findImage(_imageName)->getMaxFrameX()) _imageName = L"p_idle";
		}
		else
		{
			_index = 0;
		}

		if (_isLeft)
		{
			IMAGEMANAGER->findImage(L"p_backStep2")->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(L"p_backStep2")->getFrameWidth() / 2 - 20) - _ptCamera.x,
				(_y - IMAGEMANAGER->findImage(L"p_backStep2")->getFrameHeight()) - _ptCamera.y,
				_index, _isLeft, 150);

			IMAGEMANAGER->findImage(L"p_backStep2")->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(L"p_backStep2")->getFrameWidth() / 2 - 10) - _ptCamera.x,
				(_y - IMAGEMANAGER->findImage(L"p_backStep2")->getFrameHeight()) - _ptCamera.y,
				_index, _isLeft, 150);
		}
		else
		{
			IMAGEMANAGER->findImage(L"p_backStep2")->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(L"p_backStep2")->getFrameWidth() / 2 + 20) - _ptCamera.x,
				(_y - IMAGEMANAGER->findImage(L"p_backStep2")->getFrameHeight()) - _ptCamera.y,
				_index, _isLeft, 150);

			IMAGEMANAGER->findImage(L"p_backStep2")->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(L"p_backStep2")->getFrameWidth() / 2 + 10) - _ptCamera.x,
				(_y - IMAGEMANAGER->findImage(L"p_backStep2")->getFrameHeight()) - _ptCamera.y,
				_index, _isLeft, 150);
		}

		IMAGEMANAGER->findImage(L"p_backStep2")->alphaRender(getMemDC(), 100);
	}
	else
	{
		if (_index > IMAGEMANAGER->findImage(_imageName)->getMaxFrameX()) _index = 0;
	}

	if (_imageName != L"p_jump")
	{
		IMAGEMANAGER->findImage(_imageName)->frameRender(getMemDC(),
			(_x - IMAGEMANAGER->findImage(_imageName)->getFrameWidth() / 2) - _ptCamera.x,
			(_y - IMAGEMANAGER->findImage(_imageName)->getFrameHeight()) - _ptCamera.y,
			_index, _isLeft, _alpha);
	}

	// ����
	if (_imageName == L"p_attack")
	{
		if (_isLeft)
		{
			IMAGEMANAGER->findImage(L"P_AtkSword")->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(L"P_AtkSword")->getFrameWidth() / 2 - 30) - _ptCamera.x,
				(_y - IMAGEMANAGER->findImage(L"P_AtkSword")->getFrameHeight()) - _ptCamera.y,
				_index, _isLeft, _alpha);

			if (_index == 2)
			{
				_atkRect = RectMakeCenter(_x - 95, _y - IMAGEMANAGER->findImage(_imageName)->getFrameHeight() + 22, 65, 10);
			}
			else
			{
				_atkRect = RectMake(0, 0, 0, 0);
			}
		}
		else
		{
			IMAGEMANAGER->findImage(L"P_AtkSword")->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(L"P_AtkSword")->getFrameWidth() / 2 + 30) - _ptCamera.x,
				(_y - IMAGEMANAGER->findImage(L"P_AtkSword")->getFrameHeight()) - _ptCamera.y,
				_index, _isLeft, _alpha);

			if (_index == 2)
			{
				_atkRect = RectMakeCenter(_x + 95, _y - IMAGEMANAGER->findImage(_imageName)->getFrameHeight() + 22, 65, 10);
			}
			else
			{
				_atkRect = RectMake(0, 0, 0, 0);
			}
		}
	}
	else if (_imageName == L"p_airAttack")
	{
		if (_isLeft)
		{
			IMAGEMANAGER->findImage(L"p_airAtkSword")->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(L"p_airAtkSword")->getFrameWidth() / 2 - 30) - _ptCamera.x,
				(_y - IMAGEMANAGER->findImage(L"p_airAtkSword")->getFrameHeight()) - _ptCamera.y,
				_index - 2, _isLeft, _alpha);

			if (_index == 3)
			{
				_atkRect = RectMakeCenter(_x - 95, _y - IMAGEMANAGER->findImage(_imageName)->getFrameHeight() + 22, 65, 10);
			}
			else
			{
				_atkRect = RectMake(0, 0, 0, 0);
			}
		}
		else
		{
			IMAGEMANAGER->findImage(L"p_airAtkSword")->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(L"p_airAtkSword")->getFrameWidth() / 2 + 30) - _ptCamera.x,
				(_y - IMAGEMANAGER->findImage(L"p_airAtkSword")->getFrameHeight()) - _ptCamera.y,
				_index - 2, _isLeft, _alpha);

			if (_index == 3)
			{
				_atkRect = RectMakeCenter(_x + 95, _y - IMAGEMANAGER->findImage(_imageName)->getFrameHeight() + 22, 65, 10);
			}
			else
			{
				_atkRect = RectMake(0, 0, 0, 0);
			}
		}
	}
	else if (_imageName == L"p_sitAttack")
	{
		if (_isLeft)
		{
			IMAGEMANAGER->findImage(L"p_sitAtkSword")->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(L"p_sitAtkSword")->getFrameWidth() / 2 - 30) - _ptCamera.x,
				(_y - IMAGEMANAGER->findImage(L"p_sitAtkSword")->getFrameHeight()) - _ptCamera.y,
				_index - 3, _isLeft, _alpha);

			if (_index == 4)
			{
				_atkRect = RectMakeCenter(_x - 95, _y - IMAGEMANAGER->findImage(_imageName)->getFrameHeight() + 22, 65, 10);
			}
			else
			{
				_atkRect = RectMake(0, 0, 0, 0);
			}
		}
		else
		{
			IMAGEMANAGER->findImage(L"p_sitAtkSword")->frameRender(getMemDC(),
				(_x - IMAGEMANAGER->findImage(L"p_sitAtkSword")->getFrameWidth() / 2 + 30) - _ptCamera.x,
				(_y - IMAGEMANAGER->findImage(L"p_sitAtkSword")->getFrameHeight()) - _ptCamera.y,
				_index - 3, _isLeft, _alpha);

			if (_index == 4)
			{
				_atkRect = RectMakeCenter(_x + 95, _y - IMAGEMANAGER->findImage(_imageName)->getFrameHeight() + 22, 65, 10);
			}
			else
			{
				_atkRect = RectMake(0, 0, 0, 0);
			}
		}
	}
	else
	{
		_atkRect = RectMake(0, 0, 0, 0);
	}

	// �ܼ�â �����
	if (debug_x != _x || debug_y != _y)
	{
		debug_x = _x;
		debug_y = _y;
		cout << " x = " << debug_x << " y = " << debug_y << endl;
	}
}

// ĳ���� ������ �� Ű
void player::move()
{
	// ����
	if (KEYMANAGER->isStayKeyDown(VK_LEFT) && _imageName != L"p_sit" && _imageName != L"p_sitAttack" && _imageName != L"p_backStep" && !_isHit)
	{
		if (!_isAttack)
		{
			_isLeft = true;
			if (_gravity <= 0) _imageName = L"p_move";
		}
		if (PIXELMANAGER->leftWallCollision(IMAGEMANAGER->findImage(L"p_idle"), _x, _y, IMAGEMANAGER->findImage(L"���浹")) == NULL && _imageName != L"p_attack") _x -= 4.0f;
	}

	// ������
	if (KEYMANAGER->isStayKeyDown(VK_RIGHT) && _imageName != L"p_sit" && _imageName != L"p_sitAttack" && _imageName != L"p_backStep" && !_isHit)
	{
		if (!_isAttack)
		{
			_isLeft = false;
			if (_gravity <= 0) _imageName = L"p_move";
		}
		if (PIXELMANAGER->rightWallCollision(IMAGEMANAGER->findImage(L"p_idle"), _x, _y, IMAGEMANAGER->findImage(L"���浹")) == NULL && _imageName != L"p_attack") _x += 4.0f;
	}

	// �Է¾�������
	if (!KEYMANAGER->isStayKeyDown(VK_LEFT) && !KEYMANAGER->isStayKeyDown(VK_RIGHT))
	{
		if (_gravity <= 0 && _imageName != L"p_jump" && _imageName != L"p_backStep" && _imageName != L"p_sitAttack" && !_isAttack)
		{
			_imageName = L"p_idle";
		}
	}

	// �ɱ�
	if (_gravity <= 0 && _imageName != L"p_attack" && _imageName != L"p_backStep" && _imageName != L"p_sitAttack" && !_isHit)
	{
		if (KEYMANAGER->isOnceKeyDown(VK_DOWN))
		{
			_index = 0;
		}

		if (KEYMANAGER->isStayKeyDown(VK_DOWN))
		{
			_imageName = L"p_sit";
		}
		if (!KEYMANAGER->isStayKeyDown(VK_DOWN) && _imageName == L"p_sit")
		{
			_imageName = L"p_idle";
		}
	}

	if (KEYMANAGER->isStayKeyDown(VK_DOWN) && KEYMANAGER->isOnceKeyDown('X'))
	{
		_isGetDown = true;
	}
	else if (!KEYMANAGER->isStayKeyDown(VK_DOWN))
	{
		_isGetDown = false;
	}

	// ����
	if (KEYMANAGER->isOnceKeyDown('X') && !PIXELMANAGER->pixelCeilingCollision(IMAGEMANAGER->findImage(_imageName), _x, _y, IMAGEMANAGER->findImage(L"���浹")) && _jumpCount < 2 && !_isHit && _imageName != L"p_airAttack")
	{
		_isAttack = false;
		_index = 0;
		_gravity = 0;
		_jumpPower = 3.5f;
		++_jumpCount;
		SOUNDMANAGER->play("player_jump", _volume);

		if (PIXELMANAGER->pixelPlateCollision(IMAGEMANAGER->findImage(_imageName), _x, _y, IMAGEMANAGER->findImage(L"���浹")) != NULL && _isGetDown)
		{
			_index = 8;
		}

		_imageName = L"p_jump";
	}

	if (KEYMANAGER->isStayKeyDown('X') && _index == 2 && _imageName == L"p_jump")
	{
		_jumpPower = 7.0f;
	}

	// �� �浹
	if (PIXELMANAGER->getPixelCollisionY(IMAGEMANAGER->findImage(_imageName), _x, _y, IMAGEMANAGER->findImage(L"���浹")) != NULL && _jumpPower <= 0)
	{
		if (_imageName == L"p_jump" || _imageName == L"p_airAttack")
		{
			_imageName = L"p_idle";
			SOUNDMANAGER->play("player_shoes", _volume);
		}

		_y = PIXELMANAGER->getPixelCollisionY(IMAGEMANAGER->findImage(_imageName), _x, _y, IMAGEMANAGER->findImage(L"���浹"));
		_gravity = 0;
		_jumpPower = 0;
		_jumpCount = 0;
	}
	// ������ �� �ִ� ���� �浹
	else if (PIXELMANAGER->pixelPlateCollision(IMAGEMANAGER->findImage(_imageName), _x, _y, IMAGEMANAGER->findImage(L"���浹")) != NULL && _jumpPower <= 0 && !_isGetDown)
	{
		if (_imageName == L"p_jump" || _imageName == L"p_airAttack")
		{
			_imageName = L"p_idle";
			SOUNDMANAGER->play("player_shoes", _volume);
		}

		_y = PIXELMANAGER->pixelPlateCollision(IMAGEMANAGER->findImage(_imageName), _x, _y, IMAGEMANAGER->findImage(L"���浹"));
		_gravity = 0;
		_jumpPower = 0;
		_jumpCount = 0;
	}
	else
	{
		_imageName = L"p_jump";
		_gravity += 0.012f;
		_jumpPower -= _gravity;
		_y -= _jumpPower;
	}

	// õ�� �浹
	if (PIXELMANAGER->pixelCeilingCollision(IMAGEMANAGER->findImage(_imageName), _x, _y, IMAGEMANAGER->findImage(L"���浹")) && _jumpPower > 0)
	{
		_jumpPower = 0;
	}

	// ����
	if (KEYMANAGER->isOnceKeyDown('Z') && !_isAttack && !_isHit)
	{
		cout << "���� Ű ����!" << endl;

		_index = 0;
		_isAttack = true;

		_attackSoundRnd = RND->getInt(3);

		switch (_attackSoundRnd)
		{
			case 0:
				SOUNDMANAGER->play("player_attack1", _volume);
			break;

			case 1:
				SOUNDMANAGER->play("player_attack2", _volume);
			break;

			case 2:
				SOUNDMANAGER->play("player_attack3", _volume);
			break;
		}
	}

	if (_isAttack)
	{
		if (_imageName == L"p_idle" || _imageName == L"p_move" || _imageName == L"p_backStep")
		{
			_imageName = L"p_attack";
		}
		else if (_imageName == L"p_jump")
		{
			_imageName = L"p_airAttack";
		}
		else if (_imageName == L"p_sit")
		{
			_imageName = L"p_sitAttack";
		}
	}

	// �齺��
	if (KEYMANAGER->isOnceKeyDown('S') && _imageName != L"p_airAttack" && _imageName != L"p_jump" && _sp > 7)
	{
		_imageName = L"p_backStep";
		_backStepTimer = 0;
		_isAttack = false;
		_sp -= 7;
	}

	if (_imageName != L"p_backStep")
	{
		_backStepTimer = 0;
	}
	else
	{
		_backStepTimer += TIMEMANAGER->getElapsedTime();

		if (_isLeft)
		{
			if (PIXELMANAGER->rightWallCollision(IMAGEMANAGER->findImage(L"p_idle"), _x, _y, IMAGEMANAGER->findImage(L"���浹")) == NULL) _x += 6.0f;
		}
		else
		{
			if (PIXELMANAGER->leftWallCollision(IMAGEMANAGER->findImage(L"p_idle"), _x, _y, IMAGEMANAGER->findImage(L"���浹")) == NULL) _x -= 6.0f;
		}
	}
}