#include "stdafx.h"
#include "mainGame.h"


void mainGame::collision()
{
	RECT tempRect;

	int hitSoundRnd = RND->getInt(3);

	for (int i = 0; i < _vEnemy.size(); ++i)
	{
		if (IntersectRect(&tempRect, &_player->getHitRect(), &_vEnemy[i]->getHitRect()) || 
			IntersectRect(&tempRect, &_player->getHitRect(), &_vEnemy[i]->getAtkRect()))
		{
			_player->setHp(_player->getHp() - _vEnemy[i]->getAtk());
			_player->setHit();

			SOUNDMANAGER->play("hit", _volume);
			switch (hitSoundRnd)
			{
				case 0:
					SOUNDMANAGER->play("player_hit1", _volume);
				break;

				case 1:
					SOUNDMANAGER->play("player_hit2", _volume);
				break;

				case 2:
					SOUNDMANAGER->play("player_hit3", _volume);
				break;
			}
		}
	}
}