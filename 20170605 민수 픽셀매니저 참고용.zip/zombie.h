#pragma once
#include "enemy.h"
class zombie : public enemy
{
private:

	image* _enemyImage;
	image* _enemyHitImage;
	image* _enemyDeadImage;
	float _aliveTimer;

public:
	HRESULT init(float x, float y);
	void release(void);
	void update(void);
	void render(void);

	zombie();
	~zombie();
};

