#pragma once
#include "gameNode.h"
#include "player.h"


class enemy : public gameNode
{
protected:
	player* _player;

	// ���������� ������
	RECT _hitRect;
	RECT _atkRect;

	int _hp;
	float _x, _y;

	float _count;
	int _index;
	bool _isLeft;

	int _atk;

	float _hitTimer;
	bool _isHit;
	int _alpha;

	bool _isSelfDestroy;
	bool _isDestroyByHit;

public:
	virtual HRESULT init(float x, float y);
	virtual void release(void);
	virtual void update(void);
	virtual void render(void);

	void collision();

	// == �ζ��� �Լ� == //
	inline int getHp() { return _hp; }
	inline int getAtk() { return _atk; }
	inline RECT getHitRect() { return _hitRect; }
	inline RECT getAtkRect() { return _atkRect; }
	inline bool getSelfDestroy() { return _isSelfDestroy; }
	inline bool getHitDestroy() { return _isDestroyByHit; }
	void setPlayerAddress(player* address) { _player = address; }

	// ==
	enemy();
	~enemy();
};

