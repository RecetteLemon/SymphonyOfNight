#pragma once
#include "gameNode.h"

class progressBar : public gameNode
{
private:
	int _x, _y;
	float _width;

	image* _progressBar;

public:
	HRESULT init(const WCHAR* imageName, int x, int y);
	void release();
	void update();
	void render();

	void setGauge(float currentGauge, float maxGauge);

	//������ �� ��ġ ���� �Ծ�
	void setX(int x) { _x = x; }
	void setY(int y) { _y = y; }

	progressBar();
	~progressBar();
};

