#include "stdafx.h"
#include "pixelCollisionManager.h"


pixelCollisionManager::pixelCollisionManager()
{
}


pixelCollisionManager::~pixelCollisionManager()
{
}

HRESULT pixelCollisionManager::init(void)
{
	_color = NULL;
	_r = _g = _b = 0;
	_probeX = _probeY = 0;


	return S_OK;
}

void pixelCollisionManager::release(void)
{
}

bool pixelCollisionManager::pixelCeilingCollision(image* destImage, float destX, float destY, image* sourImage)
{
	for (int i = destY - destImage->getFrameHeight();
		i < destY - destImage->getFrameHeight() / 4; ++i)
	{
		_color = GetPixel(sourImage->getMemDC(), destX, i);

		_r = GetRValue(_color);
		_g = GetGValue(_color);
		_b = GetBValue(_color);

		if ((_r == 255 && _g == 0 && _b == 0))
		{
			return true;
		}
	}

//	for (int i = destX - destImage->getFrameWidth() / 2;
//		i < destX + destImage->getFrameWidth() / 2; ++i)
//	{
//		_color = GetPixel(sourImage->getMemDC(),i, destY);
//
//		_r = GetRValue(_color);
//		_g = GetGValue(_color);
//		_b = GetBValue(_color);
//
//		if (!(_r == 255 && _g == 0 && _b == 255))
//		{
//			return true;
//		}
//	}

	return false;
}

float pixelCollisionManager::pixelPlateCollision(image* destImage, float destX, float destY, image* sourImage)
{
	for (int i = destY;
		i < destY + destImage->getFrameHeight() / 8; ++i)
	{
		_color = GetPixel(sourImage->getMemDC(), destX, i);

		_r = GetRValue(_color);
		_g = GetGValue(_color);
		_b = GetBValue(_color);

		if ((_r == 0 && _g == 0 && _b == 255))
		{
			return destY = i;
		}
	}

	return NULL;
}

float pixelCollisionManager::leftWallCollision(image* destImage, float destX, float destY, image* sourImage)
{
	// ���� �浹
	for (int j = destY - destImage->getFrameHeight();
		j < destY; ++j)
	{
		for (int i = destX - destImage->getFrameWidth() / 2;
			i < destX; ++i)
		{
			_color = GetPixel(sourImage->getMemDC(), i, j);

			_r = GetRValue(_color);
			_g = GetGValue(_color);
			_b = GetBValue(_color);

			if ((_r == 255 && _g == 0 && _b == 0))
			{
				return destX = i + destImage->getFrameWidth() / 2;
			}
		}
	}
	
	return NULL;
}

float pixelCollisionManager::rightWallCollision(image* destImage, float destX, float destY, image* sourImage)
{
	// ������ �浹
	for (int j = destY - destImage->getFrameHeight();
		j < destY; ++j)
	{
		for (int i = destX;
			i < destX + destImage->getFrameWidth() / 2; ++i)
		{
			_color = GetPixel(sourImage->getMemDC(), i, j);

			_r = GetRValue(_color);
			_g = GetGValue(_color);
			_b = GetBValue(_color);

			if ((_r == 255 && _g == 0 && _b == 0))
			{
				return destX = i - destImage->getFrameWidth() / 2;
			}
		}
	}

	return NULL;
}

float pixelCollisionManager::getPixelCollisionY(image* destImage, float destX, float destY, image* sourImage)
{
	for (int i = destY - destImage->getFrameHeight() / 2;
		i < destY + destImage->getFrameHeight() / 4; ++i)
	{
		_color = GetPixel(sourImage->getMemDC(), destX, i);

		_r = GetRValue(_color);
		_g = GetGValue(_color);
		_b = GetBValue(_color);

		if ((_r == 0 && _g == 255 && _b == 0))
		{
			return destY = i;
		}
	}

	return NULL;
}

void pixelCollisionManager::makeHole(image* sourImage, float x, float y, float radius)
{
	HBRUSH brush = CreateSolidBrush(RGB(255, 0, 255));
	HBRUSH oldBrush = (HBRUSH)SelectObject(sourImage->getMemDC(), brush);
	HPEN pen = CreatePen(NULL, NULL, RGB(255, 0, 255));
	HPEN oldPen = (HPEN)SelectObject(sourImage->getMemDC(), pen);

	EllipseMakeCenter(sourImage->getMemDC(), x, y, radius, radius);

	DeleteObject(oldPen);
	DeleteObject(pen);
	DeleteObject(oldBrush);
	DeleteObject(brush);
}