#pragma once
#include "gameNode.h"


class player : public gameNode
{
private:
	WCHAR* _imageName;
	RECT _hitRect;
	RECT _atkRect;

	float _x, _y;
	float _count;
	int _index;
	bool _isLeft;
	bool _isAttack;
	bool _isGetDown;

	float _gravity;
	float _jumpPower;
	int _jumpCount;

	float _backStepTimer;
	bool _isBackStep;

	int _hp;
	int _maxHp;
	int _sp;
	int _maxSp;
	int _atk;

	bool _isHit;
	float _hitTimer;

	int _alpha;

	int _attackSoundRnd;

	// ����� ����
	float debug_x, debug_y;

public:
	HRESULT init(void);
	void release(void);
	void update(void);
	void render(void);

	void move();

	inline float getX() { return _x; }
	inline float getY() { return _y; }

	inline int getHp() { return _hp; }
	inline void setHp(int hp) { _hp = hp; }

	inline int getSp() { return _sp; }
	inline void setSp(int sp) { _sp = sp; }

	inline void setHit() { _isHit = true; }

	inline int getMaxHp() { return _maxHp; }
	inline int getMaxSp() { return _maxSp; }
	inline int getAtk() { return _atk; }

	inline RECT getAtkRect() { return _atkRect; }
	inline RECT getHitRect() { return _hitRect; }

	player();
	~player();
};

