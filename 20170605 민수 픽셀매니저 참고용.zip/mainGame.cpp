#include "stdafx.h"
#include "mainGame.h"


mainGame::mainGame()
{
}


mainGame::~mainGame()
{
}

//�ʱ�ȭ ���ִ� �Լ�
HRESULT mainGame::init(void)
{
	gameNode::init(true);

	_volume = 0.6f;

	// �̹��� �ֱ�
	IMAGEMANAGER->addImage(L"���", L"image/map/bg1.bmp", 1200, 800, false, RGB(255, 0, 255));
	IMAGEMANAGER->addImage(L"��", L"image/map/bg2.bmp", 4800, 474, true, RGB(255, 0, 255));

	IMAGEMANAGER->addImage(L"��", L"image/map/maps.bmp", 6478, 2516, true, RGB(255, 0, 255));
	IMAGEMANAGER->addImage(L"���浹", L"image/map/maps_collision.bmp", 6478, 2516, true, RGB(255, 0, 255));

	IMAGEMANAGER->addImage(L"ü�¹�", L"image/ui/hpBar.bmp", 192, 9, true, RGB(255, 0, 255));
	IMAGEMANAGER->addImage(L"��¹�", L"image/ui/spBar.bmp", 192, 9, true, RGB(255, 0, 255));

	IMAGEMANAGER->addFrameImage(L"����", L"image/ui/number.bmp", 132, 18, 10, 1, true, RGB(255, 0, 255));
	
	IMAGEMANAGER->addFrameImage(L"p_idle", L"image/character/player_idle.bmp", 855, 264, 15, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"p_move", L"image/character/player_move.bmp", 1440, 258, 16, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"p_jump", L"image/character/player_jump.bmp", 1404, 258, 13, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"p_sit", L"image/character/player_sit.bmp", 306, 162, 3, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"p_attack", L"image/character/player_attack.bmp", 903, 252, 7, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"p_airAttack", L"image/character/player_air_attack.bmp", 675, 246, 5, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"p_sitAttack", L"image/character/player_sit_attack.bmp", 1107, 156, 9, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"p_backStep", L"image/character/player_backStep.bmp", 162, 252, 2, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"p_backStep2", L"image/character/player_backStep.bmp", 162, 252, 2, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"p_hit", L"image/character/player_hit.bmp", 192, 246, 2, 2, true, RGB(255, 0, 255));

	IMAGEMANAGER->addFrameImage(L"P_AtkSword", L"image/character/weapon/standAttack_sword.bmp", 576, 252, 3, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"p_airAtkSword", L"image/character/weapon/airAttack_sword.bmp", 594, 246, 3, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"p_sitAtkSword", L"image/character/weapon/sitAttack_sword.bmp", 558, 156, 3, 2, true, RGB(255, 0, 255));

	IMAGEMANAGER->addFrameImage(L"zombie", L"image/enemy/zombie.bmp", 843, 240, 11, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"zombie_hit", L"image/enemy/zombie_hit.bmp", 843, 240, 11, 2, true, RGB(255, 0, 255));
	IMAGEMANAGER->addFrameImage(L"zombie_die", L"image/enemy/zombie_die.bmp", 116, 276, 1, 2, true, RGB(255, 0, 255));

	// ���� �ֱ�
	SOUNDMANAGER->addSound("bgm1", "sound/bgm/castle-corridor.mp3", true, true);

	SOUNDMANAGER->addSound("sword_hit", "sound/effect/sword_hit.wav", false, false);

	SOUNDMANAGER->addSound("player_attack1", "sound/player/player_attack1.wav", false, false);
	SOUNDMANAGER->addSound("player_attack2", "sound/player/player_attack2.wav", false, false);
	SOUNDMANAGER->addSound("player_attack3", "sound/player/player_attack3.wav", false, false);

	SOUNDMANAGER->addSound("player_hit1", "sound/player/player_hit1.wav", false, false);
	SOUNDMANAGER->addSound("player_hit2", "sound/player/player_hit2.wav", false, false);
	SOUNDMANAGER->addSound("player_hit3", "sound/player/player_hit3.wav", false, false);

	SOUNDMANAGER->addSound("player_shoes", "sound/player/player_shoes.wav", false, false);
	SOUNDMANAGER->addSound("player_jump", "sound/effect/player_jump.wav", false, false);
	SOUNDMANAGER->addSound("hit", "sound/effect/hit.wav", false, false);

	// ==

	_HUD = new image;
	_HUD->init(L"image/ui/HUD.bmp", 333, 69, true, RGB(255, 0, 255));

	_player = new player;
	_player->init();

	_hpBar = new progressBar;
	_hpBar->init(L"ü�¹�", 103, 16);

	_spBar = new progressBar;
	_spBar->init(L"��¹�", 103, 31);

	_zombieGen = 0;

	return S_OK;
}

//�޸� ���� �Լ�
void mainGame::release(void)
{
	gameNode::release();


}

//�������ִ� ��
void mainGame::update(void)
{
	gameNode::update();

	SOUNDMANAGER->update();

	// �÷��̾� ����
	_player->update();
	_hpBar->setGauge(_player->getHp(), _player->getMaxHp());
	_spBar->setGauge(_player->getSp(), _player->getMaxSp());

	setPlayerCamera();

	// �� ����
	for (int i = 0; i < _vEnemy.size(); ++i)
	{
		_vEnemy[i]->update();
		_vEnemy[i]->collision();

		// ���� �޸� ������ �ȵ� ��
		if (_vEnemy[i]->getSelfDestroy())
		{
			SAFE_DELETE(_vEnemy[i]);
			_viEnemy = _vEnemy.erase(_vEnemy.begin() + i);
		}
		else if (_vEnemy[i]->getHitDestroy())
		{
			SAFE_DELETE(_vEnemy[i]);
			_viEnemy = _vEnemy.erase(_vEnemy.begin() + i);
		}
	}

	collision();

//	for (_viEnemy = _vEnemy.begin(); _viEnemy != _vEnemy.end();)
//	{
//		if ((*_viEnemy)->getSelfDestroy())
//		{
//			SAFE_RELEASE((*_viEnemy));
//			SAFE_DELETE((*_viEnemy));
//			_viEnemy = _vEnemy.erase(_viEnemy);
//		}
//		else ++_viEnemy;
//	}

	_zombieGen += TIMEMANAGER->getElapsedTime();

	if (_zombieGen >= 2.0f)
	{
		spawnEnemy(ZOMBIE, RND->getFromFloatTo(2300.0f, 5800.0f), 2456);
		_zombieGen = 0;
	}
}

//���Ⱑ �׷��ִ� ��
void mainGame::render(void)
{
	PatBlt(getMemDC(), 0, 0, WINSIZEX, WINSIZEY, WHITENESS);
	//==============================================================================

	IMAGEMANAGER->findImage(L"���")->render(getMemDC(), 0, 0);
	IMAGEMANAGER->findImage(L"��")->render(getMemDC(), 1678.0f - _ptCamera.x, 2142.0f - _ptCamera.y);

	IMAGEMANAGER->findImage(L"��")->render(getMemDC(), -_ptCamera.x, -_ptCamera.y);

	if (KEYMANAGER->isToggleKey(VK_F1))
	{
		IMAGEMANAGER->findImage(L"���浹")->render(getMemDC(), -_ptCamera.x, -_ptCamera.y);
	}

	for (int i = 0; i < _vEnemy.size(); ++i)
	{
		_vEnemy[i]->render();
	}

	_player->render();

	_HUD->render(getMemDC(), 10, 4);
	_hpBar->render();
	_spBar->render();

	for (int i = 0; i < 3; i++)
	{
		if (_player->getHp() < 100 && i == 2) continue;

		IMAGEMANAGER->findImage(L"����")->frameRender(getMemDC(), 
			60 - (i * 16), 20,
			(_player->getHp() % (int)pow(10, i + 1) - _player->getHp() % (int)pow(10, i)) / (int)pow(10, i),
			0);
	}

	
	TIMEMANAGER->render(getMemDC());

//	WCHAR str[100];
//	wsprintf(str, L"%d", _vEnemy.size());
//	TextOut(getMemDC(), 0, 0, str, wcslen(str));
	//================================================================================
	//�ǵ������� �̰ŵ�
	this->getBackBuffer()->render(getHDC(), 0, 0);

}

void mainGame::setPlayerCamera()
{
	if (_player->getX() < 1679 && _player->getY() > 0 && _player->getY() < 2516)
	{
		_ptMaxCamera.x = 1679 - WINSIZEX;
		_ptMaxCamera.y = 2516 - WINSIZEY;

		_ptMinCamera.x = 0;
		_ptMinCamera.y = 0;
	}

	if (_player->getX() > 1679 && _player->getX() < 6478 && _player->getY() > 1916 && _player->getY() < 2516)
	{
		if (!SOUNDMANAGER->isPlaySound("bgm1"))
		{
			SOUNDMANAGER->play("bgm1", _volume);
		}

		_ptMaxCamera.x = 6478 - WINSIZEX;
		_ptMaxCamera.y = 2516 - WINSIZEY;

		_ptMinCamera.x = 1679;
		_ptMinCamera.y = 1916;
	}

	if (_player->getX() - WINSIZEX / 2 < _ptMaxCamera.x && _player->getX() - WINSIZEX / 2 > _ptMinCamera.x)
	{
		_ptCamera.x = _player->getX() - WINSIZEX / 2;
	}
	if (_player->getX() - WINSIZEX / 2 < _ptMinCamera.x)
	{
		_ptCamera.x = _ptMinCamera.x;
	}
	if (_player->getX() - WINSIZEX / 2 > _ptMaxCamera.x)
	{
		_ptCamera.x = _ptMaxCamera.x;
	}

	if (_player->getY() - WINSIZEY / 2 < _ptMaxCamera.y && _player->getY() - WINSIZEY / 2 > _ptMinCamera.y)
	{
		_ptCamera.y = _player->getY() - WINSIZEY / 2;
	}
	if (_player->getY() - WINSIZEY / 2 < _ptMinCamera.y)
	{
		_ptCamera.y = _ptMinCamera.y;
	}
	if (_player->getY() - WINSIZEY / 2 > _ptMaxCamera.y)
	{
		_ptCamera.y = _ptMaxCamera.y;
	}
}

void mainGame::spawnEnemy(ENEMY_TYPE type, float x, float y)
{
	enemy* tempEnemy;

	switch (type)
	{
		case ZOMBIE:
			tempEnemy = new zombie;
			tempEnemy->init(x, y);
		break;
	}

	tempEnemy->setPlayerAddress(_player);

	_vEnemy.push_back(tempEnemy);
}