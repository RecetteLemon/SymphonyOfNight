#pragma once
#include "singletonBase.h"
#include "image.h"
#include <map>



class imageManager : public singletonBase<imageManager>
{
private:
	//          first   second
	typedef map<wstring, image*> mapImageList;
	typedef map<wstring, image*>::iterator mapImageIter;

private:
	mapImageList _mImageList;

public:
	HRESULT init(void);
	void release(void);

	//�� ��Ʈ��
	image* addImage(wstring strKey, int width, int height);

	//���� �̹���
	image* addImage(wstring strKey, const WCHAR* fileName, int width, int height, bool trans, COLORREF transColor);
	image* addImage(wstring strKey, const WCHAR* fileName, float x, float y, int width, int height, bool trans, COLORREF transColor);
	//������ �̹���
	image* addFrameImage(wstring strKey, const WCHAR* fileName, float x, float y, int width, int height, int frameX, int frameY, bool trans, COLORREF transColor);
	image* addFrameImage(wstring strKey, const WCHAR* fileName, int width, int height, int frameX, int frameY, bool trans, COLORREF transColor);

	//Ű ������ �̹��� ã�ƿ��� �Լ�
	image* findImage(wstring strKey);

	//�̹��� �����ִ� �Լ�
	BOOL deleteImage(wstring strKey);

	//�̹��� ��ü������ �����ִ� �Լ�
	BOOL deleteAll(void);

	//void render(string strKey, HDC hdc);
	void render(wstring strKey, HDC hdc, int destX, int destY);
	void render(wstring strKey, HDC hdc, int destX, int destY, int sourX, int sourY, int sourWidth, int sourHeight);


	imageManager();
	~imageManager();
};

